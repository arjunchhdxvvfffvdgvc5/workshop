from django.db import models

# Create your models here.

class login(models.Model):
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=20)
   
class register(models.Model):
    username = models.CharField(max_length=30)
    phonenumber = models.CharField(max_length=20)
    email = models.EmailField(max_length=30)
    phonenumber = models.CharField(max_length=20)
   